### author: juchenquan
### date: 2019-04-23

makeCacheMatrix <- function(x = matrix()) {
    ### This function creates a special "matrix" object that can cache its 
    ### inverse.
    
    inv_x <- NULL
    
    set <- function(y) { ## only if input is new
        x <<- y
        inv_x <<- NULL
    }
    get <- function() {
        x
    }
    setInv <- function(inv_input) {
        inv_x <<- inv_input
    }
    getInv <- function() {
        inv_x
    }
    # create a mapping list
    list(
        set = set,
        get = get,
        setInv = setInv,
        getInv = getInv)
}


cacheSolve <- function(x, ...) {
    ### This function computes the inverse of the special "matrix" returned 
    ### by makeCacheMatrix above. If the inverse has already been calculated 
    ### (and the matrix has not changed), then cacheSolve should retrieve the 
    ### inverse from the cache.
    
    ### Return a matrix that is the inverse of 'x'
    
    inv_x <- x$getInv()
    if (!is.null(inv_x)) { # if inv_x has been calculated:
        message("getting cached data")
        return(inv_x)
    }
    
    inv_x <- solve(x$get(), ...) #calculate inverse
    x$setInv(inv_x)
    return (inv_x)
}



