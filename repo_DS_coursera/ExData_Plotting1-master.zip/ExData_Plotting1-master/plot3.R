### author: juchengquan
### date: 20190427

library("data.table")

dat <-  fread("household_power_consumption.txt",na.strings="?")

dat[, datetime := strptime(paste(dat$Date, dat$Time), format="%d/%m/%Y %H:%M:%S")]

dat_plot <- dat[(datetime >= "2007-02-01") & (datetime <="2007-02-03"), ]


png("plot3.png", width=480, height=480)
plot(dat_plot$datetime, dat_plot$Sub_metering_1, type="l",
      xlab="", ylab="Energy sub metering")
lines(dat_plot$datetime, dat_plot$Sub_metering_2, col="red")
lines(dat_plot$datetime, dat_plot$Sub_metering_3, col="blue")
legend("topright", legend=c("Sub_metering_1", "Sub_metering_2", "Sub_metering_3"),
       col=c("black", "red", "blue"), lwd=1)
dev.off()

