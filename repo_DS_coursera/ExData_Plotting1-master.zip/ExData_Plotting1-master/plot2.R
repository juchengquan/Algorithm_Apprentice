### author: juchengquan
### date: 20190427

library("data.table")

dat <-  fread("household_power_consumption.txt",na.strings="?")

dat[, Date := lapply(.SD, as.Date, format="%d/%m/%Y"), .SDcols=c("Date")] 

dat[, Global_active_power := lapply(.SD, as.numeric), .SDcols=c("Global_active_power")]

dat[, datetime := strptime(paste(dat$Date, dat$Time), format="%Y-%m-%d %H:%M:%S")]

dat_plot <- dat[(Date >= "2007-02-01") & (Date <="2007-02-02"), ]

png("plot2.png", width=480, height=480)

plot(x=dat_plot$datetime, y=dat_plot$Global_active_power, type="l",
     xlab="", ylab="Global Active Power (kilowatts)", )

dev.off()
