### author: juchengquan
### date: 20190427

library("data.table")

dat <-  fread("household_power_consumption.txt",na.strings="?")

dat[, Date := lapply(.SD, as.Date, format="%d/%m/%Y"), .SDcols=c("Date")] 

dat[, Global_active_power := lapply(.SD, as.numeric), .SDcols=c("Global_active_power")]

dat_plot1 <- dat[(Date >= "2007-02-01") & (Date <= "2007-02-02"), Global_active_power]

png("plot1.png", width=480, height=480)

hist(dat_plot1, main="Global Active Power", col="Red",
     xlab="Global Active Power (kilowatts)", ylab="Frequency")

dev.off()
