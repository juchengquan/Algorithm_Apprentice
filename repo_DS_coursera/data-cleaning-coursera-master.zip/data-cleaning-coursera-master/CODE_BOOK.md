# Code book

- all the variables have been modified and segmented with "_".

##### Variables:

- `subject`: subject identifier, integer, 1-30.

- `activity`: activity identifier, 6 values:

  `WALKING`, `WALING_UPSTAIRS`, `WALKING_DOWNSTAIRS`, `SITTING`, `STANDING`, `LAYING`.

##### Prefixes and suffixes:

- `time_domain`: time domain signals
- `frequency_domain`: frequency domain signals
- `body_acceleration`: body acceleration
- `body_acceleration_jerk`: body acceleration jerk
- `gravity_accerlation`: gravity acceleration
- `gyroscope`: gyroscope related variables
