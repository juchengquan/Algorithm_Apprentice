### author: juchengquan
### date: 2019-04-24

library(dplyr)

### download data
url_Download <- "https://d396qusza40orc.cloudfront.net/getdata%2Fprojectfiles%2FUCI%20HAR%20Dataset.zip"
local_zip <- "loc.zip"

if (!file.exists(local_zip)) {
    download.file(url_Download, local_zip,quite=TRUE)
} else {
    print("file already exists... Done")
}

### unzip data
dir_string <- "./UCI HAR Dataset"
if (!dir.exists(dir_string)) {
    unzip(local_zip, exdir="./ju")
} else{
    print("directory aleady exists... Done")
}

### read data
# training set
train_subject <- read.table(file.path(dir_string, "train", "subject_train.txt"))
train_x <- read.table(file.path(dir_string, "train", "x_train.txt"))
train_y <- read.table(file.path(dir_string, "train", "y_train.txt"))
# test set
test_subject <- read.table(file.path(dir_string, "test", "subject_test.txt"))
test_x <- read.table(file.path(dir_string, "test", "x_test.txt"))
test_y <- read.table(file.path(dir_string, "test", "y_test.txt"))
print("read data...Done.")
# feature
feature <- read.table(file.path(dir_string, "features.txt"),as.is=TRUE) #transform as characters
# acticity
activity <- read.table(file.path(dir_string, "activity_labels.txt"))

### 1. merge data
all_tab <- rbind(cbind(train_x, train_y, train_subject),
                 cbind(test_x, test_y, test_subject))

colnames(all_tab) <- c(feature$V2, "activity", "subject")
# clean data to save memory
remove( test_subject, test_x, test_y,
        train_subject, train_x, train_y)
print("merge data... Done")
    
### 2. Extracts only the measurements on the mean and standard deviation for each measurement
cols <- grep("mean|std|activity|subject",colnames(all_tab)) # still holds activity and subject for further usage
all_tab_new <- all_tab[,cols]
# clean data to save memory
remove(all_tab)
print("extract data... Done")

### 3. Uses descriptive activity names to name the activities in the data set
all_tab_new$activity <-  factor(all_tab_new$activity, levels=activity$V1, labels=activity$V2) #@@@


### 4 Appropriately labels the data set with descriptive variable names.
all_col_name <- colnames(all_tab_new)

all_col_name <- gsub("^t", "time_domain_", all_col_name)
all_col_name <- gsub("^f", "frequency_domain_", all_col_name)
all_col_name <- gsub("Body", "body_", all_col_name)
all_col_name <- gsub("Acc", "acceleration_", all_col_name)
all_col_name <- gsub("Gyro", "gyroscope_", all_col_name)
all_col_name <- gsub("Mag", "magnitude_", all_col_name)
all_col_name <- gsub("Freq", "frequency_", all_col_name)
all_col_name <- gsub("-", "_", all_col_name)
all_col_name <- gsub("\\,", "_", all_col_name)
all_col_name <- gsub("\\(\\)", "", all_col_name)

colnames(all_tab_new) <- all_col_name
print("change column name... Done")


### 5. creates a second, independent tidy data set with the average of each variable 
###    for each activity and each subject. 

#using pipeline:
all_tab_sum <- all_tab_new %>%
    group_by(., activity, subject) %>%
    summarise_each(., funs(mean))

head(all_tab_sum, 2)
print("summarize... Done")

###END_OF_CODE