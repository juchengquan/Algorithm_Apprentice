# Project of data-cleaning-coursera

### Files:

- `README.md`: overview of the entire procedure.
- `tidy_data.txt`: the clean tidy dataset.
- `CODEBOOK.md`: the code book that describes the descriptive names of all the variables. 
- `run_analysis.R`: the code. 

### Process: 

The R script executes the following procedure in sequence:

- Downloads data, if it does not exist in the local directory. 
- Merges the training and the test sets to create one data set.

- Extracts the measurements on the mean and standard deviation for each measurement.
- Uses descriptive activity names to name the activities in the data set.
- Labels the data set with descriptive variable names (see Code book).
- Creates a second, independent tidy data set with the average of each variable for each activity and each subject.
- Export tidy data as "tidy_data.txt".



