---
title: "Reproducible Research: Peer Assessment 1"
output: 
  html_document:
    keep_md: true
---


## Loading and preprocessing the data

```r
library(data.table)
library(ggplot2)

#setwd("C:\\Users\\cqju\\Dropbox\\ws_R\\5_RR")
### download data
url_Download <- "https://d396qusza40orc.cloudfront.net/repdata%2Fdata%2Factivity.zip"
local_zip <- "loc.zip"

if (!file.exists(local_zip)) {
    download.file(url_Download, local_zip, quite=TRUE)
}
### unzip data
if (!file.exists("activity.csv")) {
    unzip(local_zip)
} 
dat <- as.data.table(read.csv("activity.csv"))
```

## What is mean total number of steps taken per day?
####  1. Calculate the total number of steps taken per day

```r
tot_step <-  dat[, lapply(.SD, sum, na.rm=FALSE), .SDcols="steps", by=date]
head(tot_step)
```

```
##          date steps
## 1: 2012-10-01    NA
## 2: 2012-10-02   126
## 3: 2012-10-03 11352
## 4: 2012-10-04 12116
## 5: 2012-10-05 13294
## 6: 2012-10-06 15420
```
####  2. Make a histogram of the total number of steps taken each day

```r
ggplot(tot_step, aes(x=steps)) + geom_histogram(bins = 50) + labs(title="Daily steps")
```

```
## Warning: Removed 8 rows containing non-finite values (stat_bin).
```

![](PA1_template_files/figure-html/unnamed-chunk-3-1.png)<!-- -->

#####  3. Calculate and report the mean and median of the total number of steps taken per day

```r
cat("mean: ", mean(tot_step$steps,na.rm=TRUE), "steps\n", "median: ", median(tot_step$steps, na.rm=TRUE), "steps")
```

```
## mean:  10766.19 steps
##  median:  10765 steps
```


## What is the average daily activity pattern?
####  1.Make a time series plot (i.e. type="l") of the 5-minute interval (x-axis) and the average number of steps taken, averaged across all days (y-axis)

```r
int_5m <- dat[, lapply(.SD, sum, na.rm=TRUE), .SDcols="steps", by=interval]
ggplot(int_5m, aes(x=interval, y=steps)) + geom_line(size=1) + labs(title="average steps across all days")
```

![](PA1_template_files/figure-html/unnamed-chunk-5-1.png)<!-- -->

####  2. Which 5-minute interval, on average across all the days in the dataset, contains the maximum number of steps?

```r
cat("interval with maximum number of steps: ", int_5m$interval[which(int_5m$steps == max(int_5m$steps))])
```

```
## interval with maximum number of steps:  835
```


## Imputing missing values
####  1. Calculate and report the total number of missing values in the dataset (i.e. the total number of rows with NAs)

```r
cat("total number of missing values", nrow(dat[is.na(steps),]) )
```

```
## total number of missing values 2304
```

####  2. Devise a strategy for filling in all of the missing values in the dataset. The strategy does not need to be sophisticated. For example, you could use the mean/median for that day, or the mean for that 5-minute interval, etc.
- My strategy is to use the mean for that 5-minute interval value. 

```r
new_dat <- copy(dat)
for (i in 1:nrow(dat[is.na(steps),])) {
    new_dat[i,"steps"] <- as.integer(dat[which(dat$interval == dat$interval[i]), lapply(.SD, mean, na.rm=TRUE), .SDcols="steps"])
}
```

####  3. Create a new dataset that is equal to the original dataset but with the missing data filled in

```r
head(new_dat, 10)
```

```
##     steps       date interval
##  1:     1 2012-10-01        0
##  2:     0 2012-10-01        5
##  3:     0 2012-10-01       10
##  4:     0 2012-10-01       15
##  5:     0 2012-10-01       20
##  6:     2 2012-10-01       25
##  7:     0 2012-10-01       30
##  8:     0 2012-10-01       35
##  9:     0 2012-10-01       40
## 10:     1 2012-10-01       45
```

####  4. Make a histogram of the total number of steps taken each day and Calculate and report the mean and median total number of steps taken per day. Do these values differ from the estimates from the first part of the assignment? What is the impact of imputing missing data on the estimates of the total daily number of steps?

```r
tot_step_new <-  new_dat[, lapply(.SD, sum, na.rm=FALSE), .SDcols="steps", by=date] 
ggplot(tot_step_new, aes(x=steps)) + geom_histogram(bins=30) + labs(title="Daily steps")
```

```
## Warning: Removed 6 rows containing non-finite values (stat_bin).
```

![](PA1_template_files/figure-html/unnamed-chunk-10-1.png)<!-- -->

```r
cat("mean: ", mean(tot_step_new$steps,na.rm=TRUE), "steps\n", "median: ", median(tot_step_new$steps, na.rm=TRUE), "steps")
```

```
## mean:  10771.15 steps
##  median:  10641 steps
```


## Are there differences in activity patterns between weekdays and weekends?
####  1. Create a new factor variable in the dataset with two levels – “weekday” and “weekend” indicating whether a given date is a weekday or weekend day.

```r
new_dat$day <-  strftime(new_dat$date, "%u")
new_dat[which(new_dat$day>= 1 & new_dat$day<=5), "day"] <- "weekday"
new_dat[which(new_dat$day>= 6 & new_dat$day<=7), "day"] <- "weekend"
```

####  2. Make a panel plot containing a time series plot (i.e. type="l") of the 5-minute interval (x-axis) and the average number of steps taken, averaged across all weekday days or weekend days (y-axis). See the README file in the GitHub repository to see an example of what this plot should look like using simulated data.

```r
tot_step_new_day <- new_dat[, lapply(.SD, sum, na.rm=TRUE), .SDcols="steps", by=.(interval, day)]
ggplot(tot_step_new_day, aes(x=interval, y=steps, color=day)) +
    geom_line(size=1) +
    facet_wrap(~day, ncol=1, nrow=2,) +
    labs(title="Daily steps by weekday/weekend", color="Week type") 
```

![](PA1_template_files/figure-html/unnamed-chunk-12-1.png)<!-- -->
